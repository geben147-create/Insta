import csv,json,re,hashlib,datetime,os,subprocess,collections,shutil,fcntl
from pathlib import Path
W=Path(__file__).parent
ROOT=Path('/run/media/yh/새 볼륨/틱톡/샤오(한국 일본 영상들)')
OUT=ROOT/'동기화점검'/'20261120_140138_Hermes'
OUT.mkdir(exist_ok=True)
(W/'output_path.txt').write_text(str(OUT))
lock=(OUT/'audit.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
(OUT/'resume.json').write_text(json.dumps({'pid':os.getpid(),'started':datetime.datetime.now().isoformat(),'scope':'870 read-only originals; new audit outputs only','PC_current':'UNKNOWN'},ensure_ascii=False,indent=2))
for p in W.iterdir():
 if p.suffix in ['.md','.tsv'] and not (OUT/p.name).exists():shutil.copyfile(p,OUT/p.name)
PAT=re.compile(r'BV[A-Za-z0-9]{10}|(?:XHS)?[a-fA-F0-9]{24}|(?<![0-9])[0-9]{18,20}(?![0-9])|VIDE[A-Za-z0-9]{20,40}|8JiyJejo-e0')
def ident(s):
 m=PAT.search(s)
 if not m:return 'UNKNOWN'
 v=m.group();return v[3:].lower() if v.startswith('XHS') else (v.lower() if re.fullmatch('[a-fA-F0-9]{24}',v) else v)
def rows(n):return list(csv.DictReader((W/n).open(encoding='utf-8-sig'),delimiter='\t'))
def tsv(n,rr):
 if not rr:return
 if (OUT/n).exists():return
 keys=list(dict.fromkeys(k for r in rr for k in r))
 with (OUT/n).open('x',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,keys,delimiter='\t');w.writeheader();w.writerows({k:('UNKNOWN' if v is None or v=='' else v) for k,v in r.items()} for r in rr)
def digest(p):
 st=p.stat();h=hashlib.sha256()
 with p.open('rb') as f:
  for chunk in iter(lambda:f.read(8*1024*1024),b''):h.update(chunk)
 en=p.stat();return h.hexdigest(),(st.st_size,st.st_mtime_ns)==(en.st_size,en.st_mtime_ns)
records={};pc=collections.defaultdict(list);candidates={};expected=collections.defaultdict(list)
for n in ['korea-direct-latest.tsv','japan-direct-latest.tsv','sync-exceptions-20261117.tsv']:
 for r in rows(n):
  i=ident(r['ID']);records.setdefault(i,{}).update(r)
  if r.get('870 계산 SHA256'):expected[i].append(r['870 계산 SHA256'])
for r in rows('PC-remaining-20261117.tsv'):
 i=ident(r['전체경로']);pc[i].append(r);records.setdefault(i,{})
for n in ['new-sources-20261117.tsv','korea-japan-additional-nonyoutube-queue-20261118.tsv']:
 for r in rows(n):
  raw=r.get('ID',r.get('id'));i=ident(raw)
  if i=='UNKNOWN':i=raw
  candidates.setdefault(i,{'sources':[],'url':r.get('URL',r.get('url')),'platform':r.get('플랫폼','UNKNOWN'),'title':r.get('제목',r.get('title','UNKNOWN'))})['sources'].append(n)
  records.setdefault(i,{})
files=[p for p in ROOT.rglob('*') if p.is_file() and OUT not in p.parents]
video=[];subs=[];parts=[]
for p in files:
 i=ident(p.name)
 if i=='UNKNOWN':i=ident(str(p.parent))
 if p.suffix.lower() in ['.mp4','.mkv','.webm','.mov','.flv','.m4v']:
  video.append((i,p));records.setdefault(i,{})
 elif p.suffix.lower() in ['.srt','.vtt']:subs.append((i,p))
 elif p.suffix=='.part':parts.append({'ID':i,'path':str(p),'bytes':p.stat().st_size})
tsv('partial_files.tsv',parts)
TIME=re.compile(r'(?:(\d+):)?(\d{2}):(\d{2})[,.](\d{3})')
def sec(s):
 m=TIME.search(s)
 if not m:return None
 h,mi,se,ms=m.groups();return int(h or 0)*3600+int(mi)*60+int(se)+int(ms)/1000
sr=[]
for i,p in subs:
 try:
  text=p.read_text(encoding='utf-8-sig',errors='replace');lines=text.splitlines();cues=[];empty=bad=back=0;last=-1;body=[]
  for k,line in enumerate(lines):
   if '-->' not in line:continue
   start,end=line.split('-->',1);a,b=sec(start),sec(end)
   if a is None or b is None or b<=a:bad+=1
   if a is not None and a<last:back+=1
   if a is not None:last=a
   bb=[]
   for ll in lines[k+1:]:
    if not ll.strip() or '-->' in ll:break
    bb.append(re.sub('<[^>]*>','',ll).strip())
   txt=' '.join(bb).strip();empty+=not bool(txt);body.append(txt);cues.append((a,b))
  joined=' '.join(body);ko=bool(re.search(r'(?:[._-])(?:ko|kor|korean)(?:[._-]|$)',p.name,re.I))
  lang='ko' if ko else ('zh' if re.search(r'(?:[._-])(?:zh|zh-cn|zh-Hans|ai-zh)(?:[._-]|$)',p.name,re.I) else 'UNKNOWN')
  issues=[]
  if not cues:issues.append('NO_CUES')
  if empty:issues.append('EMPTY_CUES')
  if bad:issues.append('INVALID_TIMECODES')
  if back:issues.append('NONMONOTONIC_START')
  if not joined:issues.append('EMPTY_BODY')
  if ko and not re.search('[가-힣]',joined):issues.append('KO_WITHOUT_HANGUL')
  if re.search(r'TODO|translation pending|번역 필요|번역 대기|^UNKNOWN$',joined,re.I):issues.append('PLACEHOLDER')
  h,stable=digest(p)
  if not stable:issues.append('CHANGED_DURING_SCAN')
  sr.append({'ID':i,'path':str(p),'bytes':p.stat().st_size,'sha256':h,'role':'ko' if ko else 'original_or_other','language':lang,'cues':len(cues),'empty_cues':empty,'bad_times':bad,'nonmonotonic':back,'body_chars':len(joined),'hangul':bool(re.search('[가-힣]',joined)),'first_start':cues[0][0] if cues else None,'last_end':cues[-1][1] if cues else None,'structure':'PASS' if not issues else 'FAIL','issues':'|'.join(issues),'semantic_review':'UNKNOWN'})
 except Exception as e:sr.append({'ID':i,'path':str(p),'structure':'FAIL','error':str(e)})
tsv('subtitle_files.tsv',sr)
by_sub=collections.defaultdict(list)
for r in sr:by_sub[r['ID']].append(r)
checkpoint=OUT/'video_checkpoint.jsonl'
vr=[json.loads(x) for x in checkpoint.read_text().splitlines()] if checkpoint.exists() else []
done={r['path'] for r in vr}
for n,(i,p) in enumerate(video,1):
 if str(p) in done:continue
 try:
  h,stable=digest(p);size=p.stat().st_size
  z=subprocess.run(['ffprobe','-v','error','-show_entries','format=duration:stream=codec_type','-of','json',str(p)],capture_output=True,text=True,timeout=20)
  meta=json.loads(z.stdout or '{}');streams=meta.get('streams',[]);ok=z.returncode==0 and any(s.get('codec_type')=='video' for s in streams)
  vr.append({'ID':i,'path':str(p),'bytes':size,'sha256':h,'stable':stable,'container':'PASS' if ok else 'FAIL','audio_stream':any(s.get('codec_type')=='audio' for s in streams),'duration':meta.get('format',{}).get('duration','UNKNOWN'),'expected_hash':'MATCH' if h in expected[i] else ('MISMATCH' if expected[i] else 'UNKNOWN'),'error':z.stderr[:300]})
 except Exception as e:vr.append({'ID':i,'path':str(p),'container':'FAIL','error':str(e)})
 with checkpoint.open('a') as cf:cf.write(json.dumps(vr[-1],ensure_ascii=False)+'\n')
 if n%25==0:print('HASH_PROBE',n,'/',len(video),flush=True)
tsv('video_files.tsv',vr)
by_video=collections.defaultdict(list)
for r in vr:by_video[r['ID']].append(r)
links=[];candrows=[]
for i,r in sorted(records.items()):
 vv=by_video[i];ss=by_sub[i];orig=[s for s in ss if s.get('role')!='ko' and s.get('structure')=='PASS'];ko=[s for s in ss if s.get('role')=='ko' and s.get('structure')=='PASS']
 v=sorted(vv,key=lambda a:(a.get('container')!='PASS',a.get('expected_hash')!='MATCH',a['path']))[0] if vv else {}
 o=sorted(orig,key=lambda s:(s.get('language')=='UNKNOWN',s['path']))[0] if orig else {};k=sorted(ko,key=lambda s:s['path'])[0] if ko else {}
 reasons=[]
 if not vv:reasons.append('NO_VIDEO_IN_870_SCOPE')
 elif v.get('container')!='PASS' or not v.get('stable'):reasons.append('VIDEO_INVALID_OR_CHANGED')
 if not o:reasons.append('ORIGINAL_MISSING_OR_INVALID')
 if not k:reasons.append('KO_MISSING_OR_INVALID')
 if o and o.get('language')=='UNKNOWN':reasons.append('ORIGINAL_LANGUAGE_UNCONFIRMED')
 if o and k and o.get('cues')!=k.get('cues'):reasons.append('CUE_COUNT_MISMATCH_REVIEW')
 c=candidates.get(i,{})
 if c:reasons.append('CONTENT_CLAIMS_UNVERIFIED')
 state='검수필요' if vv else '차단'
 if vv and v.get('container')=='FAIL':state='실패'
 link={'ID':i,'status':state,'reason':'|'.join(reasons) or 'SEMANTIC_REVIEW_REQUIRED','platform':c.get('platform',r.get('플랫폼','UNKNOWN')),'url':c.get('url',r.get('원본 URL','UNKNOWN')),'video_path':v.get('path','UNKNOWN'),'video_bytes':v.get('bytes','UNKNOWN'),'video_sha256':v.get('sha256','UNKNOWN'),'video_container':v.get('container','UNKNOWN'),'original_path':o.get('path','UNKNOWN'),'original_sha256':o.get('sha256','UNKNOWN'),'original_language':o.get('language','UNKNOWN'),'ko_path':k.get('path','UNKNOWN'),'ko_sha256':k.get('sha256','UNKNOWN'),'subtitle_structural_pair':'PASS' if o and k else 'FAIL','PC_current_path':'UNKNOWN','PC_current_bytes':'UNKNOWN','PC_current_sha256':'UNKNOWN','PC_historical_paths':json.dumps([x['전체경로'] for x in pc[i]],ensure_ascii=False) if pc[i] else 'UNKNOWN','PC_historical_bytes':json.dumps([x['바이트'] for x in pc[i]]) if pc[i] else 'UNKNOWN','pc_870_hash_comparison':'UNKNOWN','praise_speech':'UNKNOWN','direct_korea_japan_comparison':'UNKNOWN','media_type':'VIDEO_CONTAINER' if v.get('container')=='PASS' else 'UNKNOWN','semantic_review':'UNKNOWN','next_action':'TRANSLATE_ONLY' if o and not k else ('FETCH_PLATFORM_CAPTIONS_THEN_WHISPER' if vv and not o else 'REVIEW')}
 links.append(link)
 if c:
  cc=dict(link);cc['candidate_sources']='|'.join(c['sources']);cc['title']=c['title'];cc['download_action']='REUSE_EXISTING' if vv else ('EXCLUDE_YOUTUBE' if 'youtube.com' in c['url'] or 'youtu.be' in c['url'] else 'BLOCKED_PC_INVENTORY_UNKNOWN')
  candrows.append(cc)
tsv('id_video_subtitle_links.tsv',links);tsv('candidate_reconciliation.tsv',candrows)
summary={'root':str(ROOT),'output':str(OUT),'video_files':len(vr),'video_unique_ids':len({v['ID'] for v in vr}),'subtitle_files':len(sr),'subtitle_structure':dict(collections.Counter(s['structure'] for s in sr)),'video_container':dict(collections.Counter(v['container'] for v in vr)),'video_bytes':sum(v.get('bytes',0) for v in vr),'linked_ids':len(links),'candidates_unique':len(candrows),'candidate_actions':dict(collections.Counter(r['download_action'] for r in candrows)),'id_status':dict(collections.Counter(r['status'] for r in links)),'PC_current':'UNKNOWN','pc_historical_rows':sum(map(len,pc.values())),'partial_files':len(parts),'completed_semantic':0,'note':'All original media read-only. Subtitle PASS means structure only, not original-language or translation accuracy. Current PC inventory unavailable; no missing-on-both claim.'}
(OUT/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2));print(json.dumps(summary,ensure_ascii=False,indent=2),flush=True)
