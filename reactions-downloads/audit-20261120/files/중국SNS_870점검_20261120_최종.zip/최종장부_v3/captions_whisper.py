import csv,json,re,subprocess,os,fcntl,time,hashlib
from pathlib import Path
W=Path(__file__).parent
ROOT=Path('/run/media/yh/새 볼륨/틱톡/샤오(한국 일본 영상들)')
OUT=ROOT/'추가보완_20261120_1416'
lock=(OUT/'whisper.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
# Refuse if another Whisper worker is active. Exclude this script and shell wrappers.
for p in Path('/proc').iterdir():
 if not p.name.isdigit() or int(p.name)==os.getpid():continue
 try:
  argv=(p/'cmdline').read_bytes().split(b'\0');args=[x.decode(errors='replace') for x in argv]
  if any(Path(x).name in ['whisper_all.py','whisper_missing.py','whisper_one.py','whisper'] for x in args[:3]):raise RuntimeError('OTHER_WHISPER_ACTIVE_PID_'+p.name)
 except (FileNotFoundError,PermissionError,ProcessLookupError):pass
subs=list(csv.DictReader((ROOT/'동기화점검/20261120_140138_Hermes/subtitle_files.tsv').open(encoding='utf-8-sig'),delimiter='\t'))
valid={s['ID'] for s in subs if s['role']=='original_or_other' and s['structure']=='PASS'}
cand={}
for n in ['new-sources-20261117.tsv','korea-japan-additional-nonyoutube-queue-20261118.tsv']:
 for r in csv.DictReader((W/n).open(),delimiter='\t'):
  i=r.get('ID',r.get('id'));u=r.get('URL',r.get('url'))
  if i.startswith('BV') and i not in valid:cand[i]=u
log=OUT/'whisper_caption_events.jsonl'
def event(d):
 with log.open('a') as f:f.write(json.dumps(d,ensure_ascii=False)+'\n')
 print(json.dumps(d,ensure_ascii=False),flush=True)
def ts(t):
 ms=round(t*1000);return f'{ms//3600000:02}:{ms//60000%60:02}:{ms//1000%60:02},{ms%1000:03}'
model=None
device=os.environ.get('WHISPER_DEVICE','cpu')
budget=int(os.environ.get('WHISPER_BUDGET','3'))
attempted=0
for i,url in cand.items():
 videos=[p for p in ROOT.rglob(i+'*.mp4') if OUT not in p.parents]
 if not videos:continue
 # Reject unmuxed video-only fragments; don't re-download existing media.
 video=None
 for p in videos:
  q=subprocess.run(['ffprobe','-v','error','-show_entries','stream=codec_type','-of','json',str(p)],capture_output=True,text=True,timeout=20)
  if q.returncode==0 and any(s['codec_type']=='audio' for s in json.loads(q.stdout).get('streams',[])):video=p;break
 if video is None:event({'ID':i,'status':'검수필요','reason':'NO_READABLE_AUDIO_STREAM'});continue
 d=OUT/i;d.mkdir(exist_ok=True)
 existing=list(d.glob('*.srt'))+list(d.glob('*.vtt'))
 if not (d/'platform_caption_attempt.log').exists():
  cmd=['/usr/bin/yt-dlp','--skip-download','--no-playlist','--no-overwrites','--write-info-json','--write-subs','--write-auto-subs','--sub-langs','zh.*,en.*,ko.*,ja.*','--sub-format','srt/vtt/best','--socket-timeout','12','--retries','1','--extractor-retries','1','-P',str(d),'-o','%(id)s.%(ext)s',url]
  try:
   q=subprocess.run(cmd,capture_output=True,text=True,timeout=60);(d/'platform_caption_attempt.log').write_text(q.stdout+'\n'+q.stderr);rc=q.returncode
  except subprocess.TimeoutExpired as e:(d/'platform_caption_attempt.log').write_text(str(e));rc='TIMEOUT'
 else:rc='PRIOR_ATTEMPT_LOG'
 fetched=[p for p in list(d.glob('*.srt'))+list(d.glob('*.vtt')) if p not in existing]
 if fetched:event({'ID':i,'status':'검수필요','action':'PLATFORM_CAPTION_FETCH','paths':[str(p) for p in fetched],'returncode':rc});continue
 # No anonymous-access platform speech subtitles. Danmaku is not a transcript.
 event({'ID':i,'phase':'NO_PLATFORM_SPEECH_CAPTIONS','returncode':rc,'scope':'anonymous accessible captions only'})
 if attempted>=budget:event({'ID':i,'status':'검수필요','action':'WHISPER_QUEUED','reason':'CPU_BATCH_BUDGET; CUDA12_LIBRARY_UNAVAILABLE'});continue
 if model is None:
  from faster_whisper import WhisperModel
  mp='/home/yh/.cache/huggingface/hub/models--Systran--faster-whisper-medium/snapshots/08e178d48790749d25932bbc082711ddcfdfbc4f'
  try:model=WhisperModel(mp,device=device,device_index=0 if device=='cpu' else 1,compute_type='int8' if device=='cpu' else 'float16',local_files_only=True,cpu_threads=8)
  except Exception as e:event({'phase':'CUDA_MODEL_LOAD_FAILED','error':str(e)});raise
 original=d/(i+'.whisper.srt')
 if original.exists():continue
 attempted+=1
 try:
  segs,info=model.transcribe(str(video),vad_filter=True,beam_size=5);segs=list(segs)
  if not segs or any(not s.text.strip() or s.end<=s.start for s in segs):raise ValueError('EMPTY_OR_INVALID_ASR')
  with original.open('x',encoding='utf-8') as f:
   for n,s in enumerate(segs,1):f.write(f'{n}\n{ts(s.start)} --> {ts(s.end)}\n{s.text.strip()}\n\n')
  event({'ID':i,'status':'검수필요','action':'WHISPER_FALLBACK','video_path':str(video),'source_path':str(original),'source_sha256':hashlib.sha256(original.read_bytes()).hexdigest(),'detected_language':info.language,'language_probability':info.language_probability,'cues':len(segs),'model':'faster-whisper-medium local '+device+(' int8 threads8' if device=='cpu' else ' GPU1 float16'),'semantic_review':'UNKNOWN'})
 except Exception as e:event({'ID':i,'status':'실패','action':'WHISPER_FALLBACK','reason':str(e)})
event({'phase':'caption_whisper_batch_finished'})
