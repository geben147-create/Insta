import json,csv,re,hashlib,urllib.request,urllib.parse,subprocess,os,fcntl,datetime,time
from pathlib import Path
W=Path(__file__).parent
OUT=Path('/run/media/yh/새 볼륨/틱톡/샤오(한국 일본 영상들)/추가보완_20261120_1416')
lock=(OUT/'enhance.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
if not (OUT/'run.json').exists():(OUT/'run.json').write_text(json.dumps({'pid':os.getpid(),'start':datetime.datetime.now().isoformat(),'policy':'no video download; no original overwrite; translation only for valid existing caption; metadata original language unconfirmed'},ensure_ascii=False))
log=OUT/'enhancement_events.jsonl'
def event(d):
 with log.open('a') as f:f.write(json.dumps(d,ensure_ascii=False)+'\n')
 print(json.dumps(d,ensure_ascii=False),flush=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def parse(p):
 text=p.read_text(encoding='utf-8-sig');ls=text.splitlines();out=[]
 for n,l in enumerate(ls):
  if '-->' not in l:continue
  bb=[]
  for x in ls[n+1:]:
   if not x.strip() or '-->' in x:break
   bb.append(re.sub('<[^>]*>','',x).strip())
  out.append((l,' '.join(bb)))
 return out
def translate(text,lang='auto'):
 url='https://translate.googleapis.com/translate_a/single?'+urllib.parse.urlencode({'client':'gtx','sl':lang,'tl':'ko','dt':'t','q':text})
 req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0'})
 for attempt in range(3):
  try:
   d=json.load(urllib.request.urlopen(req,timeout=25));return ''.join(x[0] for x in d[0] if x[0])
  except Exception:
   if attempt==2:raise
   time.sleep(1+attempt)
def translate_file(i,p,origin_role='platform_caption_original_language_UNKNOWN'):
 d=OUT/i;d.mkdir(exist_ok=True);out=d/(i+'.translated.ko.srt')
 if out.exists():return
 cues=parse(p);texts=[x[1] for x in cues]
 if not texts or any(not x for x in texts):event({'ID':i,'status':'실패','reason':'SOURCE_EMPTY_CUES'});return
 translated=[]
 try:
  for start in range(0,len(texts),12):
   batch=texts[start:start+12];result=translate('\n'.join(batch)).strip().splitlines()
   if len(result)!=len(batch) or any(not s.strip() for s in result):result=[translate(s).strip() for s in batch]
   if any(not s for s in result):raise ValueError('EMPTY_TRANSLATION')
   translated.extend(result)
  if len(translated)!=len(cues):raise ValueError('CUE_COUNT_MISMATCH')
  if not any(re.search('[가-힣]',s) for s in translated):raise ValueError('NO_HANGUL_TRANSLATION')
  with out.open('x',encoding='utf-8') as f:
   for n,((timing,source),target) in enumerate(zip(cues,translated),1):f.write(f'{n}\n{timing.replace(".",",")}\n{target}\n\n')
  # Readback checks target exact cue timing and no empty bodies.
  verify=parse(out)
  if len(verify)!=len(cues) or any(not x[1] for x in verify) or any(a[0].replace('.',',')!=b[0] for a,b in zip(cues,verify)):raise ValueError('READBACK_FAILED')
  event({'ID':i,'status':'검수필요','action':'TRANSLATE_ONLY','source_path':str(p),'source_sha256':sha(p),'source_role':origin_role,'ko_path':str(out),'ko_sha256':sha(out),'cues':len(cues),'empty_translation_cues':0,'structure':'PASS','translation_engine':'Google translate public endpoint; auto language; machine translation','semantic_review':'UNKNOWN'})
 except Exception as e:event({'ID':i,'status':'실패','action':'TRANSLATE_ONLY','source_path':str(p),'reason':str(e)})
if os.environ.get('TRANSLATE_NEW_ASR')=='1':
 for source in OUT.rglob('*.whisper.srt'):
  translate_file(source.name.split('.')[0],source,'WHISPER_DETECTED_ORIGINAL; ASR_SEMANTICS_UNVERIFIED')
else:
 for x in json.loads((W/'translation_todo.json').read_text()):
  source=Path(x['orig'][0]['path']);translate_file(x['id'],source)
event({'phase':'translation_batch_finished'})
