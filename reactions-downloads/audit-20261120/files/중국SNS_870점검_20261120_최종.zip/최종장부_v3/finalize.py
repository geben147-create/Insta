import csv,json,re,hashlib,collections,datetime,shutil,subprocess
from pathlib import Path
W=Path(__file__).parent
ROOT=Path('/run/media/yh/새 볼륨/틱톡/샤오(한국 일본 영상들)')
A=ROOT/'동기화점검/20261120_140138_Hermes'
E=ROOT/'추가보완_20261120_1416'
F=A/'최종장부_v3'
F.mkdir(exist_ok=False)
def read(n):return list(csv.DictReader((A/n).open(encoding='utf-8-sig'),delimiter='\t'))
def write(n,rs,fields=None):
 keys=fields or list(dict.fromkeys(k for r in rs for k in r))
 with (F/n).open('x',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,keys,delimiter='\t');w.writeheader()
  for r in rs:w.writerow({k:('UNKNOWN' if r.get(k) is None or r.get(k)=='' else r[k]) for k in keys})
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def events(n):
 p=E/n;return [json.loads(x) for x in p.read_text().splitlines()] if p.exists() else []
videos=read('video_files.tsv');subs=read('subtitle_files.tsv');links=read('id_video_subtitle_links.tsv');cands=read('candidate_reconciliation.tsv')
for s in subs:
 try:Path(s['path']).read_text(encoding='utf-8-sig')
 except UnicodeDecodeError:
  s['structure']='FAIL';s['issues']=('' if s.get('issues')=='UNKNOWN' else s.get('issues','')+'|')+'UTF8_DECODE_ERROR'
trans={e['ID']:e for e in events('enhancement_events.jsonl') if e.get('ko_path')}
asr={e['ID']:e for e in events('whisper_caption_events.jsonl') if e.get('source_path') and e.get('action')=='WHISPER_FALLBACK' and e.get('status')!='실패'}
byvid=collections.defaultdict(list)
for r in videos:byvid[r['ID']].append(r)
def timings(p):
 text=Path(p).read_text(encoding='utf-8-sig',errors='replace');ls=text.splitlines();cc=[]
 for k,l in enumerate(ls):
  if '-->' not in l:continue
  bb=[]
  for b in ls[k+1:]:
   if not b.strip() or '-->' in b:break
   bb.append(b.strip())
  cc.append((l.replace('.',','),' '.join(bb)))
 return cc
newsubs=[];translation_verify=[]
for i,t in trans.items():
 source=Path(t['source_path']);target=Path(t['ko_path']);s=timings(source);k=timings(target)
 ok=sha(source)==t['source_sha256'] and sha(target)==t['ko_sha256'] and len(s)==len(k)>0 and all(a[0]==b[0] and bool(b[1]) for a,b in zip(s,k))
 assert ok,('TRANSLATION_VERIFY_FAILED',i)
 translation_verify.append({'ID':i,'status':'완료_STRUCTURAL_ONLY','source_path':str(source),'source_sha256':sha(source),'ko_path':str(target),'ko_sha256':sha(target),'cues':len(k),'empty_translation_cues':sum(not x[1] for x in k),'identical_timings':True,'source_role':t['source_role'],'semantic_review':'UNKNOWN'})
 newsubs.append({'ID':i,'path':str(target),'bytes':target.stat().st_size,'sha256':sha(target),'role':'ko','language':'ko','cues':len(k),'empty_cues':0,'bad_times':0,'nonmonotonic':0,'body_chars':sum(len(x[1]) for x in k),'hangul':True,'structure':'PASS','semantic_review':'UNKNOWN','provenance':'NEW_MACHINE_TRANSLATION'})
for i,a in asr.items():
 p=Path(a['source_path']);ss=timings(p);assert sha(p)==a['source_sha256']
 newsubs.append({'ID':i,'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p),'role':'original_asr','language':a['detected_language'],'cues':len(ss),'empty_cues':sum(not x[1] for x in ss),'structure':'PASS' if ss and all(x[1] for x in ss) else 'FAIL','semantic_review':'UNKNOWN','provenance':a['model']})
allsubs=subs+newsubs
bad_sub_paths={s['path'] for s in allsubs if s['structure']=='FAIL'}
metas={}
for r in cands:
 i=r['ID'];p=Path(r['video_path']) if r['video_path']!='UNKNOWN' else None
 if p:
  for q in [p.with_suffix('.info.json'),p.parent/'metadata.json']:
   if q.exists():
    try:metas[i]=json.loads(q.read_text());break
    except Exception:pass
def platform(i,url,existing):
 host=url.lower()
 if 'douyin.com' in host:return 'Douyin','SOURCE_URL'
 if 'tiktok.com' in host:return 'TikTok','SOURCE_URL'
 if any(x in host for x in ['xiaohongshu.com','rednote.com','xhslink.com']):return 'rednote/Xiaohongshu','SOURCE_URL'
 if 'bilibili.com' in host or i.startswith('BV'):return 'Bilibili','SOURCE_URL_OR_BVID'
 if 'cctv.com' in host:return 'CCTV','SOURCE_URL'
 if 'youtube.com' in host or 'youtu.be' in host:return 'YouTube','SOURCE_URL_EXCLUDED_FROM_NEW_COLLECTION'
 if 'rutube.ru' in host:return 'Rutube','SOURCE_URL'
 if 'vk.' in host or 'vkvideo.ru' in host:return 'VK Video','SOURCE_URL'
 return existing,'UNKNOWN'
final=[]
def seconds(s):
 m=re.search(r'(?:(\d+):)?(\d{2}):(\d{2})[,.](\d{3})',s)
 if not m:return None
 h,mi,se,ms=m.groups();return int(h or 0)*3600+int(mi)*60+int(se)+int(ms)/1000
for r in links:
 x=dict(r);i=x['ID'];x['platform'],x['platform_evidence']=platform(i,x['url'],x['platform']);x['original_candidate_path']=x['original_path'];x['original_candidate_sha256']=x['original_sha256'];x['source_caption_path']=x['original_path'];x['source_caption_sha256']=x['original_sha256'];x['original_role_evidence']='FILENAME_ONLY_NOT_LANGUAGE_VERIFICATION';x['original_language_evidence']='UNKNOWN';x['video_audio_stream']=next((v['audio_stream'] for v in byvid[i] if v['path']==r['video_path']),'UNKNOWN')
 if x['original_path']!='UNKNOWN' and not Path(x['original_path']).name.endswith('.whisper.srt'):
  x['original_path']='UNKNOWN';x['original_sha256']='UNKNOWN';x['original_role_evidence']='PLATFORM_OR_OTHER_CAPTION_NOT_CONFIRMED_AUDIO_ORIGINAL'
 if i in asr:
  a=asr[i];x.update(original_path=a['source_path'],original_sha256=a['source_sha256'],original_language=a['detected_language'],original_language_evidence='WHISPER_LANGUAGE_DETECTION_NOT_HUMAN_VERIFIED',original_role_evidence='GENERATED_FROM_EXACT_VIDEO_PATH',source_caption_path=a['source_path'],source_caption_sha256=a['source_sha256'])
 if i in trans:
  t=trans[i];x['ko_path']=t['ko_path'];x['ko_sha256']=t['ko_sha256'];x['source_caption_path']=t['source_path'];x['source_caption_sha256']=t['source_sha256'];x['subtitle_structural_pair']='PASS'
  if i not in asr:x['original_path']='UNKNOWN';x['original_sha256']='UNKNOWN';x['original_role_evidence']='EXISTING_PLATFORM_CAPTION_AUDIO_LANGUAGE_UNCONFIRMED'
  x['next_action']='HUMAN_AUDIO_LANGUAGE_AND_TRANSLATION_REVIEW'
  x['reason']='|'.join(z for z in x['reason'].split('|') if z not in ['KO_MISSING_OR_INVALID','CUE_COUNT_MISMATCH_REVIEW'])
  if i in asr:x['reason']='|'.join(z for z in x['reason'].split('|') if z not in ['ORIGINAL_MISSING_OR_INVALID','ORIGINAL_LANGUAGE_UNCONFIRMED'])+'|NEW_ASR_AND_TRANSLATION_REQUIRE_HUMAN_REVIEW'
 x['content_status']='검수필요' if r['video_path']!='UNKNOWN' else '차단';x['asset_status']='완료' if r['video_path']!='UNKNOWN' and r['video_container']=='PASS' else ('차단' if r['video_path']=='UNKNOWN' else '실패')
 if x['video_audio_stream']=='False':x['reason']+='|NO_AUDIO_STREAM_REVIEW; MAY_BE_SILENT_MEDIA_OR_UNMUXED_FRAGMENT'
 x['source_post_type']='UNKNOWN';x['praise_speech']='UNKNOWN';x['direct_korea_japan_comparison']='UNKNOWN';x['human_review']='UNKNOWN'
 x['subtitle_reuse_decision']='HOLD_FOR_CONTENT_REVIEW'
 if x['source_caption_path'] in bad_sub_paths or x['ko_path'] in bad_sub_paths:
  x['subtitle_structural_pair']='FAIL';x['reason']+='|SELECTED_SUBTITLE_QUALITY_FAIL';x['next_action']='RESELECT_VALID_SUBTITLE_OR_REPAIR_SEPARATELY'
 selected_cues={}
 duration=next((float(v['duration']) for v in byvid[i] if v['path']==r['video_path'] and v['duration']!='UNKNOWN'),None)
 for role in ['source_caption','ko']:
  path=x[role+'_path'];state='UNKNOWN'
  if path!='UNKNOWN' and duration is not None:
   cc=timings(path);selected_cues[role]=cc;ends=[seconds(t.split('-->',1)[1]) for t,b in cc];ends=[z for z in ends if z is not None]
   if ends:state='FAIL_OUTSIDE_VIDEO' if max(ends)>duration+2 else ('REVIEW_LARGE_TAIL_GAP' if duration-max(ends)>max(30,duration*.15) else 'WITHIN_VIDEO_BOUNDS')
  x[role+'_range_state']=state
  if state=='FAIL_OUTSIDE_VIDEO':x['reason']+='|'+role.upper()+'_EXCEEDS_VIDEO_DURATION';x['next_action']='SUBTITLE_RANGE_REVIEW_BEFORE_REUSE'
 if set(selected_cues)=={'source_caption','ko'}:
  same=[a[0] for a in selected_cues['source_caption']]==[b[0] for b in selected_cues['ko']];x['selected_timeline_status']='MATCH' if same else 'DIFFERENT_REVIEW'
  if not same:x['reason']+='|SELECTED_CUE_TIMELINES_DIFFER';x['next_action']='SUBTITLE_ALIGNMENT_REVIEW_BEFORE_REUSE'
 else:x['selected_timeline_status']='UNKNOWN'
 final.append(x)
lookup={r['ID']:r for r in final};fc=[]
for c in cands:
 x=dict(c);x.update(lookup[c['ID']]);x['title']=c['title'];x['candidate_sources']=c['candidate_sources'];x['download_action']=c['download_action'];x['candidate_status']='차단' if c['download_action']!='REUSE_EXISTING' else '검수필요'
 if c['download_action']=='EXCLUDE_YOUTUBE':x['reason']='USER_EXCLUDED_YOUTUBE_FROM_NEW_COLLECTION'
 fc.append(x)
write('ID별_영상_원어_한국어_경로_SHA256.tsv',final)
write('후보208_ID대조_다운로드판정.tsv',fc)
write('자막_전체_품질검사.tsv',allsubs)
write('기존자막_품질실패.tsv',[s for s in subs if s['structure']=='FAIL'])
write('한국어번역_검증완료.tsv',translation_verify)
write('영상_중복포함_2064_해시.tsv',videos)
pending=[]
caption_attempts={p.parent.name for p in E.rglob('platform_caption_attempt.log')}
for r in final:
 if r['video_path']=='UNKNOWN':continue
 action='REVIEW_ONLY'
 if r['source_caption_path']=='UNKNOWN':action='WHISPER_PENDING_AFTER_PLATFORM_ATTEMPT' if r['ID'] in caption_attempts else 'FETCH_PLATFORM_CAPTIONS_THEN_WHISPER'
 elif r['ko_path']=='UNKNOWN':action='TRANSLATE_ONLY'
 if r['video_audio_stream']=='False':action='CHECK_SILENT_MEDIA_OR_UNMUXED_FRAGMENT_FIRST'
 if action!='REVIEW_ONLY':pending.append({'ID':r['ID'],'platform':r['platform'],'video_path':r['video_path'],'video_sha256':r['video_sha256'],'source_caption_path':r['source_caption_path'],'ko_path':r['ko_path'],'next_action':action,'status':'검수필요'})
write('후속_자막보완_작업큐.tsv',pending)
def seconds(s):
 m=re.search(r'(?:(\d+):)?(\d{2}):(\d{2})[,.](\d{3})',s)
 if not m:return None
 h,mi,se,ms=m.groups();return int(h or 0)*3600+int(mi)*60+int(se)+int(ms)/1000
ranges=[]
for s in allsubs:
 vv=byvid.get(s['ID'],[])
 if not vv:continue
 duration=max(float(v['duration']) for v in vv if v['duration']!='UNKNOWN')
 cues=timings(s['path']);ends=[seconds(t.split('-->',1)[1]) for t,b in cues]
 ends=[x for x in ends if x is not None]
 last=max(ends) if ends else None
 state='UNKNOWN' if last is None else ('FAIL_OUTSIDE_VIDEO' if last>duration+2 else ('REVIEW_LARGE_TAIL_GAP' if duration-last>max(30,duration*.15) else 'WITHIN_VIDEO_BOUNDS'))
 ranges.append({'ID':s['ID'],'path':s['path'],'sha256':s['sha256'],'video_duration_seconds':duration,'subtitle_last_end_seconds':last,'range_status':state,'note':'A tail gap is review evidence only; silence/music is possible. Bounds PASS is not coverage or semantic approval.'})
write('자막_영상길이_범위검사.tsv',ranges)
pairs=[]
for r in final:
 if r['source_caption_path']=='UNKNOWN' or r['ko_path']=='UNKNOWN':continue
 oo=timings(r['source_caption_path']);kk=timings(r['ko_path']);equal=[a[0] for a in oo]==[b[0] for b in kk]
 pairs.append({'ID':r['ID'],'source_path':r['source_caption_path'],'ko_path':r['ko_path'],'source_cues':len(oo),'ko_cues':len(kk),'timeline_status':'MATCH' if equal else 'DIFFERENT_REVIEW','semantic_review':'UNKNOWN'})
write('원문_한국어_큐타임코드_대조.tsv',pairs)
pcs=[]
for r in final:
 if r['PC_historical_paths']=='UNKNOWN':continue
 pcs.append({k:r[k] for k in ['ID','PC_historical_paths','PC_historical_bytes','PC_current_path','PC_current_bytes','PC_current_sha256','video_path','video_bytes','video_sha256','pc_870_hash_comparison']})
write('PC과거290_870현행_ID대조.tsv',pcs)
fields=list(fc[0])
for st in ['완료','실패','검수필요','차단']:write(st+'.tsv',[x for x in fc if x['candidate_status']==st],fields)
attempts=events('whisper_caption_events.jsonl')+events('enhancement_events.jsonl');bad=[x for x in attempts if x.get('status')=='실패' or x.get('phase')=='CUDA_MODEL_LOAD_FAILED'];write('실패_시도이력_최종실패와별개.tsv',bad)
summary={'captured':datetime.datetime.now().isoformat(),'root':str(ROOT),'final_output':str(F),'video_files_hashed':len(videos),'video_unique_ids':len({v['ID'] for v in videos}),'video_bytes':sum(int(v['bytes']) for v in videos),'video_container_pass':sum(v['container']=='PASS' for v in videos),'video_stable_during_hash':sum(v['stable']=='True' for v in videos),'video_no_audio_stream_files':sum(v['audio_stream']=='False' for v in videos),'indexed_hash_comparison':dict(collections.Counter(v['expected_hash'] for v in videos)),'initial_subtitle_files':len(subs),'initial_subtitle_structure':dict(collections.Counter(s['structure'] for s in subs)),'new_translated_ko':len(trans),'new_whisper_original':len(asr),'new_translation_cues':sum(x['cues'] for x in translation_verify),'empty_new_translation_cues':sum(x['empty_translation_cues'] for x in translation_verify),'candidate_unique':len(fc),'candidate_status':dict(collections.Counter(x['candidate_status'] for x in fc)),'candidate_action':dict(collections.Counter(x['download_action'] for x in fc)),'linked_ids':len(final),'PC_current':'UNKNOWN','PC_access':'UNAVAILABLE: TCP22 timeout both candidate Tailscale Windows nodes; source PC identity UNKNOWN; no saved host key or usable agent key','PC_historical_rows':len(pcs),'PC_historical_ids_found_870':sum(x['video_path']!='UNKNOWN' for x in pcs),'PC_historical_ids_not_found_870':sum(x['video_path']=='UNKNOWN' for x in pcs),'PC_870_hash_comparison':'UNKNOWN','new_videos_downloaded':0,'whole_video_content_completed':0,'attempt_failures_historical':len(bad),'original_files_modified_by_this_task':False,'economy_onepage_modified':False,'github_written':False,'notes':['Video count is paths, unique ID count separately deduplicated.','Structural PASS is not semantic approval.','Existing TikTok English captions reused, not mislabeled as Douyin or Chinese original speech.','Xiaohongshu missing source-post photo/video type remains UNKNOWN.','Missing-on-both cannot be established without current PC inventory.','Current PC hash comparison remains UNKNOWN; historical 290 inventory is not current.']}
assert len(videos)==2064 and len({v['ID'] for v in videos})==1486
assert len(fc)==208 and len({x['ID'] for x in fc})==208
assert len(pcs)==290 and sum(summary['candidate_status'].values())==208
summary.update({'pending_subtitle_actions':dict(collections.Counter(x['next_action'] for x in pending)),'subtitle_range_status':dict(collections.Counter(x['range_status'] for x in ranges)),'paired_timeline_status':dict(collections.Counter(x['timeline_status'] for x in pairs)),'existing_subtitle_utf8_decode_failures':sum('UTF8_DECODE_ERROR' in x.get('issues','') for x in subs),'candidate_status_all_categories':{st:sum(x['candidate_status']==st for x in fc) for st in ['완료','실패','검수필요','차단']}})
(F/'최종요약.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
for p in W.glob('*.py'):shutil.copyfile(p,F/p.name)
shutil.copyfile(A/'PC_읽기전용_현행목록.ps1',F/'PC_읽기전용_현행목록.ps1')
files=[p for p in F.iterdir() if p.is_file()]
write('결과물_SHA256.tsv',[{'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)} for p in files])
print(json.dumps(summary,ensure_ascii=False,indent=2))
